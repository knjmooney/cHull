/*
Author: Mingcen Gao and Cao Thanh Tung
Date: 27/10/2011

File Name: GHull.h

This file contains the main CUDA code including all initialization and so on. 

===============================================================================

Copyright (c) 2011, School of Computing, National University of Singapore. 
All rights reserved.

Project homepage: http://www.comp.nus.edu.sg/~tants/ghull/index.html

If you use GPUDT and you like it or have comments on its usefulness etc., we 
would love to hear from you at <tants@comp.nus.edu.sg>. You may share with us
your experience and any possibilities that we may improve the work/code.

===============================================================================

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of
conditions and the following disclaimer. Redistributions in binary form must reproduce
the above copyright notice, this list of conditions and the following disclaimer
in the documentation and/or other materials provided with the distribution. 

Neither the name of the National University of University nor the names of its contributors
may be used to endorse or promote products derived from this software without specific
prior written permission from the National University of Singapore. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
DAMAGE.

*/

#pragma once
#define REAL			    float

//vertex structure
typedef struct{
	REAL coordinates[3];
}gVertex;

//star structure: contains the vertex and the index in links
typedef struct{
	bool isDead;
	int firstEdgeIndex;
	int size;
	int space;
}gStar;

//link structure, used for find a link for certain site
typedef struct{
	int id;
	bool checked;
}gEdge;

//the input format
typedef struct {
    int noVertices;     // Number of vertices
    int maxValue;       // Coordinates are within [0, maxValue)
    int fboSize;        // Texture size to be used.
    int projectionSize; 
	int screenSize;
    gVertex *vertices;       // List of vertices
} gInput; 

//the output format for star
typedef struct{
	int noVertices;
	gStar* stars;
	gEdge* edges;
}gOutput;

//triangle structure
typedef struct{
	int vert[3];
	int neiTri[3];	//coded: the loweset 2 bits are the vertex position of the opposite triangle
} gOriTriangle;

//the output format for triangle
typedef struct{
	int noVertices;     // Number of vertices
	int * VmapT;		//coded: the loweset 2 bits are the position of the point in the triangle
	int noTriangles;
	gOriTriangle* triangles;
}gStandardOutput;

class GHull
{
private:
	//input parameters
	int _seedNum;
	int _outputType; 
	int _fboSize;
	int _projectionSize;
	int _screenSize;
	int _maxValue;
	int _status;
	gVertex * _vertices;
	gOutput _starOutput;
	gStandardOutput _triOutput;
	gInput _input;
	bool GHull::IsReadable(int outputType);
public:
	/*-----------------------Constructor & Destructor-----------------------*/
	/** GHull(REAL * vertices, int seednum, int maxvalue)
	 * The constructor of the class
	 * float * vertices: the coordinates of vertices. The length of this array should be 3 times as the length of vertices
	 * int seednum: the number of vertices
	 * int maxvalue: the coordinates of vertices are within (0, maxValue)
	 */
	GHull(REAL * vertices, int seednum, int maxvalue);
	
	/** REAL * vertices, int seednum, int maxvalue, int outputtype, int fbosize, int projectionsize, int screensize)
	 * The constructor of the class
	 * float * vertices: the coordinates of vertices. The length of this array should be 3 times as the length of vertices
	 * int seednum: the number of vertices
	 * int maxvalue: the coordinates of vertices are within (0, maxValue)
	 * int outputtype: the type of output(either GHull::TRIANGLE or GHull::STAR)
	 * int fbosize: texture size used to compute digital Voronoi Diagram in Phase 1
	 * int projectionsize: the size of region into which points are projected in Phase 1
	 * int screensize: the size of screen used for depth test in Phase 4
	 */
	GHull(REAL * vertices, int seednum, int maxvalue, int outputtype, int fbosize, int projectionsize, int screensize);
	
	/** ~GHull(void)
	 * The destructor
	 */
	~GHull(void);

	/*-----------------------Convex Hull Computation-----------------------*/
	/** static void setEnvironment(int deviceid)
	 * Set the environment of the computation. This static function mush be called before any computation of ghull
	 * int deviceid: the ID of GPU device used for computation. One can use deviceQuery in CUDA SDK to query the GPUs 
	 *		installed in the machine.
	 */
	static void setEnvironment(int deviceid);

	/** double ComputeConvexHull()
	 * Do the convex hull computation.
	 * Return double: the time of computing. Note that this value is slightly smaller than the time value of running this function,
	 *		because copying time is exclusive from this value.
	 */
	double ComputeConvexHull();

	/*-----------------------Convex Hull Query-----------------------*/
	/** int GetVerticesNum()
	 * Return int: the number of all vertices. Return -1 if the query is invalid
	 */
	int GetVerticesNum();

	/** bool GetVertexAt(int vertexid, REAL coord[3])
	 * Query the coordinates of a vertiex
	 * int vertexid: the ID of one vertex, which is in the domain [0, GetVerticesNum()]
	 * float coord[3]: the coordinates of the vertex
	 * Return bool: true if the query succeeds
	 */
	bool GetVertexAt(int vertexid, REAL coord[3]);

	/** int GetStarsNum()
	 * Return int: the number of all stars. Return -1 if the query is invalid
	 * Note: the function should only be used when the outputtype is set as GHull::STAR in the constructor
	 */
	int GetStarsNum();
	
	/** bool GetStarAt(int starid, gStar & star)
	 * Query the star of index starid
	 * int starid: the index of searched star, which is in the domain [0, GetStarsNum()]
	 * gStar & star: the star of the Vertex vertexid as the output of this function
	 * Return bool: true if the query succeeds
	 * Note: the function should only be used when the outputtype is set as GHull::STAR in the constructor
	 */
	bool GetStarAt(int starid, gStar & star);
	
	/** int * GetNeiIdsAroundStar(int starid, int &size)
	 * Query the IDs of all vertices in the star
	 * int starid: the ID of searched star, which is in the domain [0, GetStarsNum()]
	 * int & size: the number of the vertices in the star, as one of outputs of this function
	 * Return int *: the pointer of IDs of all its neighbors. Return NULL if the query fails
	 * Note: the function should only be used when the outputtype is set as GHull::STAR in the constructor
	 */
	int * GetNeiIdsAroundStar(int starid, int &size);
	
	/** int GetTrianglesNum()
	 * Query the total number of triangles of the convex hull
	 * Return int: the number of all triangles. Return -1 if the query is invalid
	 * Note: the function should only be used when the outputtype is set as GHull::TRIANGLE in the constructor
	 */
	int GetTrianglesNum();
	
	/** bool GetTriangleAt(int triid, int vertex[3])
	 * Query the triangle of index triid
	 * int triid: the ID of one triangle, which is in the domain [0, GetTrianglesNum()]
	 * int vertex[3]: 3 IDs of the vertices of the searched triangle
	 * Return bool: true if the query succeeds 
	 * Note: the function should only be used when the outputtype is set as GHull::TRIANGLE in the constructor
	 */
	bool GetTriangleAt(int triid, int vertex[3]);
	
	/** int * GetTriangleIdsAroundVertex(int vertexid, int & size)
	 * Query all triangles containing the vertex vertexid
	 * int vertexid: the ID of the vertex, which is in the domain [0, GetVerticesNum()]
	 * int & size: the size of all triangles containing vertex vertexid
	 * Return int *: the pointer of IDs of all triangles containing vertex vertexid. Return NULL if the query is invalid
	 * Note: the function should only be used when the outputtype is set as GHull::TRIANGLE in the constructor
	 */
	int * GetTriangleIdsAroundVertex(int vertexid, int & size);
	
	/** bool GetTriangleIdsAroundTriangle(int triid, int triangleIds[3])
	 * Query three neighbor triangles of triangle triid
	 * int triid: the ID of one triangle, which is in the domain [0, GetTrianglesNum()]
	 * int triangleIds[3]: the 3 IDs of the neighbor triangles of the Triangle triid
	 * Return bool: true if the query succeeds 
	 * Note: the function should only be used when the outputtype is set as GHull::TRIANGLE in the constructor
	 */
	bool GetTriangleIdsAroundTriangle(int triid, int triangleIds[3]);
	
	/** int GetTriangleIdOppositeVertex(int vertexid, int triid)
	 * Get the opposite triangle of vertex vertexid, given the triangle triid
	 * int vertexid: the ID of one vertex, which is in the domain [0, GetVerticesNum()]
	 * int triid: the ID of one triangle, which is in the domain [0, GetTrianglesNum()]
	 * Return int: the id of the opposite triangle. Return -1 if the query is invalid
	 * Note: the function should only be used when the outputtype is set as GHull::TRIANGLE in the constructor
	 */
	int GetTriangleIdOppositeVertex(int vertexid, int triid);
	

	static const enum OUTPUTTYEPE{STAR, TRIANGLE};	//output type
	static const enum STATUS{INITIALIZING, INITIALIZED, COMPUTING, COMPUTED, FINISHED, RELEASING, RELEASED};
};