/*
Author: Cao Thanh Tung and Mingcen Gao 
Date: 27/10/2011

File Name: GHull.h

This file contains the main CUDA code including all initialization and so on. 

===============================================================================

Copyright (c) 2011, School of Computing, National University of Singapore. 
All rights reserved.

Project homepage: http://www.comp.nus.edu.sg/~tants/ghull/index.html

If you use GPUDT and you like it or have comments on its usefulness etc., we 
would love to hear from you at <tants@comp.nus.edu.sg>. You may share with us
your experience and any possibilities that we may improve the work/code.

===============================================================================

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of
conditions and the following disclaimer. Redistributions in binary form must reproduce
the above copyright notice, this list of conditions and the following disclaimer
in the documentation and/or other materials provided with the distribution. 

Neither the name of the National University of University nor the names of its contributors
may be used to endorse or promote products derived from this software without specific
prior written permission from the National University of Singapore. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
DAMAGE.

*/

#include <math.h>
#include "TrackBall.h"

#define PI      3.141592654

TrackBall::TrackBall()
{
    // Set default window size
    width = 512; height = 512; 

    // Initialize the rotation matrix
    rotation[3 * 4 + 0] = 0.0; 
    rotation[3 * 4 + 1] = 0.0; 
    rotation[3 * 4 + 2] = 0.0; 
    rotation[3 * 4 + 3] = 1.0; 
    rotation[2 * 4 + 3] = 0.0; 
    rotation[1 * 4 + 3] = 0.0; 
    rotation[0 * 4 + 3] = 0.0; 

    // Reset the rotation
    Reset(); 
}

TrackBall::~TrackBall()
{
}

void TrackBall::Reset()
{
    qx = qy = qz = 0.0; 
    qw = 1.0; 

    ComputeRotationMatrix(); 
}

void TrackBall::SetWindowSize(int w, int h) 
{
    width = w; 
    height = h; 
}

double* TrackBall::GetRotationMatrix()
{
    return rotation; 
}

void TrackBall::ComputeRotationMatrix() 
{
    rotation[0 * 4 + 0] = 1 - 2 * qy * qy - 2 * qz * qz; 
    rotation[1 * 4 + 0] = 2 * qx * qy - 2 * qw * qz; 
    rotation[2 * 4 + 0] = 2 * qx * qz + 2 * qw * qy; 
    rotation[0 * 4 + 1] = 2 * qx * qy + 2 * qw * qz; 
    rotation[1 * 4 + 1] = 1 - 2 * qx * qx - 2 * qz * qz; 
    rotation[2 * 4 + 1] = 2 * qy * qz - 2 * qw * qx; 
    rotation[0 * 4 + 2] = 2 * qx * qz - 2 * qw * qy; 
    rotation[1 * 4 + 2] = 2 * qy * qz + 2 * qw * qx; 
    rotation[2 * 4 + 2] = 1 - 2 * qx * qx - 2 * qy * qy; 
}

void TrackBall::ptov(int x, int y, double v[3])
{
    double d, a; 

    v[0] = (2.0 * x - width) / width; 
    v[1] = (height - 2.0 * y) / height; 
    d = sqrt(v[0] * v[0] + v[1] * v[1]); 
    v[2] = cos((PI/2.0) * ((d < 1.0) ? d : 1.0)); 
    a = 1.0 / sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); 
    v[0] *= a; v[1] *= a; v[2] *= a; 
}

void TrackBall::StartDrag(int x, int y)
{
    oldX = x; oldY = y; 
    ox = qx; oy = qy; oz = qz; ow = qw; 
}

void TrackBall::Drag(int x, int y)
{
    double oldPos[3], newPos[3], dPos[3]; 
    double rx, ry, rz, rw; 
    double angle, sin_angle, axis[3], len; 

    // Project points onto the sphere
    ptov(oldX, oldY, oldPos); 
    ptov(x, y, newPos); 

    dPos[0] = newPos[0] - oldPos[0]; 
    dPos[1] = newPos[1] - oldPos[1]; 
    dPos[2] = newPos[2] - oldPos[2]; 

    if (dPos[0] != 0 || dPos[1] != 0 || dPos[2] != 0) {
        // Rotation angle and axis
        axis[0] = oldPos[1] * newPos[2] - oldPos[2] * newPos[1]; 
        axis[1] = oldPos[2] * newPos[0] - oldPos[0] * newPos[2]; 
        axis[2] = oldPos[0] * newPos[1] - oldPos[1] * newPos[0]; 
        angle = sqrt(dPos[0] * dPos[0] + dPos[1] * dPos[1] + dPos[2] * dPos[2]);                 

        // Rotation Quaternion
        sin_angle = sin(angle); 
        rx = axis[0] * sin_angle; 
        ry = axis[1] * sin_angle; 
        rz = axis[2] * sin_angle; 
        rw = cos(angle); 

        // Concatenate with the old rotation
        qx = ry * oz - rz * oy + rx * ow + ox * rw; 
        qy = rz * ox - rx * oz + ry * ow + oy * rw; 
        qz = rx * oy - ry * ox + rz * ow + oz * rw; 
        qw = rw * ow - rx * ox - ry * oy - rz * oz; 

        len = sqrt(qx * qx + qy * qy + qz * qz + qw * qw); 

        qx /= len; qy /= len; qz /= len; qw /= len; 

        ComputeRotationMatrix(); 
    }
}

void TrackBall::Rotate(double axis_x, double axis_y, double axis_z, double angle)
{
    double rx, ry, rz, rw; 
    double sin_angle, len; 

    // Rotation Quaternion
    sin_angle = sin(angle); 
    rx = axis_x * sin_angle; 
    ry = axis_y * sin_angle; 
    rz = axis_z * sin_angle; 
    rw = cos(angle); 

    // Concatenate with the old rotation
    ox = qx; oy = qy; oz = qz; ow = qw; 
    qx = ry * oz - rz * oy + rx * ow + ox * rw; 
    qy = rz * ox - rx * oz + ry * ow + oy * rw; 
    qz = rx * oy - ry * ox + rz * ow + oz * rw; 
    qw = rw * ow - rx * ox - ry * oy - rz * oz; 

    len = sqrt(qx * qx + qy * qy + qz * qz + qw * qw); 

    qx /= len; qy /= len; qz /= len; qw /= len; 

    ComputeRotationMatrix(); 
}