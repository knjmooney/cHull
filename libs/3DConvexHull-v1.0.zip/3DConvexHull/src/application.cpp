/*
Author: Mingcen Gao and Cao Thanh Tung
Date: 27/10/2011

File Name: GHull.h

This file contains the main CUDA code including all initialization and so on. 

===============================================================================

Copyright (c) 2011, School of Computing, National University of Singapore. 
All rights reserved.

Project homepage: http://www.comp.nus.edu.sg/~tants/ghull/index.html

If you use GPUDT and you like it or have comments on its usefulness etc., we 
would love to hear from you at <tants@comp.nus.edu.sg>. You may share with us
your experience and any possibilities that we may improve the work/code.

===============================================================================

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of
conditions and the following disclaimer. Redistributions in binary form must reproduce
the above copyright notice, this list of conditions and the following disclaimer
in the documentation and/or other materials provided with the distribution. 

Neither the name of the National University of University nor the names of its contributors
may be used to endorse or promote products derived from this software without specific
prior written permission from the National University of Singapore. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
DAMAGE.

*/

#pragma warning(disable: 4018 4101 4715)

#include <math.h>
#include <time.h>
#include <GL/glut.h>

#include "glFunction.h"
#include "gHull.h"

#define PI                  3.1415926535897932384626433

using namespace std;

//**********************************************************************************************
//* Global Vars
//**********************************************************************************************
/**********************************************************************************************
* CREATE VERTICES
**********************************************************************************************/
//**********************************************************************************************
//* Random Point Generator
//**********************************************************************************************
// Random number generator, obtained from http://oldmill.uchicago.edu/~wilder/Code/random/
unsigned long z, w, jsr, jcong; // Seeds
void randinit(unsigned long x_) 
{ z =x_; w = x_; jsr = x_; jcong = x_; }
unsigned long znew() 
{ return (z = 36969 * (z & 0xfffful) + (z >> 16)); }
unsigned long wnew() 
{ return (w = 18000 * (w & 0xfffful) + (w >> 16)); }
unsigned long MWC()  
{ return ((znew() << 16) + wnew()); }
unsigned long SHR3()
{ jsr ^= (jsr << 17); jsr ^= (jsr >> 13); return (jsr ^= (jsr << 5)); }
unsigned long CONG() 
{ return (jcong = 69069 * jcong + 1234567); }
unsigned long rand_int()         // [0,2^32-1]
{ return ((MWC() ^ CONG()) + SHR3()); }
double random()     // [0,1)
{ return ((double) rand_int() / (double(ULONG_MAX)+1)); }

void random(REAL* vertices, int seednum, int maxvalue, int distribution, double sphereRadius, double thickness)
{
	static int randseed = 0; 

    randinit(randseed++);
	REAL coor[3];
	REAL d; 
    double f, q, r; 
    bool survive; 
    for (int i = 0; i < seednum; i++)
    {
        switch (distribution)
        {
        case 0:
            for(int j = 0; j < 3; j++)
			{
				coor[j] = random();
			}
            break;
        case 1: 	
			do
			{
				coor[0] = random();
				coor[1] = random();
				coor[2] = random();
			}while(pow(coor[0]-0.5, 2.0) + pow(coor[1] - 0.5, 2.0) + pow(coor[2]-0.5, 2.0)>sphereRadius* sphereRadius);

            break;
        case 2: 
            f = random() * 2.0 * PI; 
            q = random() * PI; 
            r = sphereRadius - random() * thickness; 

    		coor[0] = 0.5 + r * sin(q) * cos(f); 
            coor[1] = 0.5 + r * sin(q) * sin(f); 
            coor[2] = 0.5 + r * cos(q); 

            break; 
        case 3: 
            survive = false; 

            while (!survive) 
            {
                int side = rand_int() % 6; 
                r = random(); 
                q = random(); 
                f = random() * thickness; 

                switch (side) 
                {
                case 0: coor[0] = r; coor[1] = q; coor[2] = f; break; 
                case 1: coor[0] = r; coor[1] = q; coor[2] = 1.0 - f; break; 
                case 2: coor[1] = r; coor[2] = q; coor[0] = f; break; 
                case 3: coor[1] = r; coor[2] = q; coor[0] = 1.0 - f; break; 
                case 4: coor[2] = r; coor[0] = q; coor[1] = f; break; 
                default: coor[2] = r; coor[0] = q; coor[1] = 1.0 - f; break; 
                }
                
                int count = 0; 
                if (coor[0] < thickness) count++; 
                if (coor[0] > 1.0 - thickness) count++; 
                if (coor[1] < thickness) count++; 
                if (coor[1] > 1.0 - thickness) count++; 
                if (coor[2] < thickness) count++; 
                if (coor[2] > 1.0 - thickness) count++; 

                survive = (random() < (1.0 / count)); 
            }
            break; 
        case 4: 	
            f = random() * 2.0 * PI; 
            q = random() * PI; 
            r = sphereRadius - thickness; 

    		coor[0] = 0.5 + r * sin(q) * cos(f); 
            coor[1] = 0.5 + r * sin(q) * sin(f); 
            coor[2] = 0.5 + r * cos(q); 

            break;
        }

		for(int j = 0; j < 3; j++)
		{
			vertices[i*3+j] = coor[j]*maxvalue;
		}
    }
	return;
}
void registerGlobalData(GHull * _thisGHull, double _maxValue, int _outputType)
{
	ghull = _thisGHull;
	maxValue = _maxValue;
	outputType = _outputType;
}
void initialVisualization(int argc, char *argv[])
{	
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH | GLUT_ALPHA|GLUT_STENCIL); 
    glutInit(&argc, argv);  
    glutInitWindowPosition(400, 0); 
    glutInitWindowSize(winSize, winSize);
}
void registerVisualization()
{
    glutReshapeFunc(glut_reshape);
	glutMouseFunc(glut_mouse); 
	glutMotionFunc(glut_mouseMotion); 
    glutKeyboardFunc(glut_keyboard);
	glutDisplayFunc(glut_display);
	glutIdleFunc(glut_display);
    glutMainLoop();  
}

int main(int argc, char *argv[])
{
	bool visualization = true;
	if(visualization)
	{
		initialVisualization(argc, argv);
	}

	int device = 0;
	int seedNum = 1000000;
	int outputType = GHull::TRIANGLE;
	int fboSize = 1024;
	int projectionSize = 800;
	int screenSize = 512;
	int maxValue = 1024;
	int distribution = 2;
	float ballfactor = 0.5;
	float thickness = 0.01;
	REAL * vertices = new REAL[seedNum*3];
	printTest(device, seedNum, outputType, fboSize, projectionSize, screenSize, maxValue, ballfactor, thickness, distribution);

	GHull::setEnvironment(device);

	random(vertices, seedNum, maxValue, distribution, ballfactor, thickness);
	GHull convexHull(vertices, seedNum, maxValue, outputType, fboSize, projectionSize, screenSize);
	double time = convexHull.ComputeConvexHull();
	printf("Computing time: %.2f ms\n",time);
	
	delete[] vertices;
	if(visualization)
	{
		registerGlobalData(&convexHull, maxValue, outputType);
		registerVisualization();
	}
	
	return 0;
}