/*
Author: Mingcen Gao and Cao Thanh Tung
Date: 27/10/2011

File Name: GHull.h

This file contains the main CUDA code including all initialization and so on. 

===============================================================================

Copyright (c) 2011, School of Computing, National University of Singapore. 
All rights reserved.

Project homepage: http://www.comp.nus.edu.sg/~tants/ghull/index.html

If you use GPUDT and you like it or have comments on its usefulness etc., we 
would love to hear from you at <tants@comp.nus.edu.sg>. You may share with us
your experience and any possibilities that we may improve the work/code.

===============================================================================

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of
conditions and the following disclaimer. Redistributions in binary form must reproduce
the above copyright notice, this list of conditions and the following disclaimer
in the documentation and/or other materials provided with the distribution. 

Neither the name of the National University of University nor the names of its contributors
may be used to endorse or promote products derived from this software without specific
prior written permission from the National University of Singapore. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
DAMAGE.

*/

#pragma warning(disable: 4996)

#include <string.h>
#include <string>

using namespace std;

#include "TrackBall.h"
#include "gHull.h"

bool isLeftMouseActive = false;
bool isRightMouseActive = false; 
bool isMiddleMouseActive = false; 
int oldMouseX = 0; 
int oldMouseY = 0; 
float scale = 1.0;
float transX = 0.0;
float transY = 0.0;
bool mouseMove = false;

bool showPoints = true; 
bool showTriangles = true; 
bool showBox = true;
bool lightOn = true; 

TrackBall trackball; 
GHull *ghull;
double maxValue;
int outputType;
int winSize = 512;

//tool
void normalVector(REAL * v0, REAL *v1, REAL *v2, REAL *n)
{
    float a[3], b[3]; 

    a[0] = v0[0] - v1[0]; 
    a[1] = v0[1] - v1[1]; 
    a[2] = v0[2] - v1[2]; 

    b[0] = v1[0] - v2[0]; 
    b[1] = v1[1] - v2[1]; 
    b[2] = v1[2] - v2[2]; 

    n[0] = (a[1] * b[2]) - (a[2] * b[1]);
    n[1] = (a[2] * b[0]) - (a[0] * b[2]);
    n[2] = (a[0] * b[1]) - (a[1] * b[0]);

    // Normalize
    float dist = sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2]); 

    if (dist == 0.0) 
        dist = 1.0; 

    n[0] /= -dist; 
    n[1] /= -dist; 
    n[2] /= -dist; 
}

//------------------gl function
void glut_reshape(int width,int height)
{
    trackball.SetWindowSize(width, height); 
}

void glut_mouse(int button, int state, int x, int y)
{
    int modifiers = glutGetModifiers(); 

	if (state == GLUT_UP)
	{
		switch (button)
	    {
		    case GLUT_LEFT_BUTTON:
    			isLeftMouseActive = false;
                isMiddleMouseActive = false; 
	    		break;
            case GLUT_RIGHT_BUTTON:
                isRightMouseActive = false; 
                break; 
            case GLUT_MIDDLE_BUTTON:
                isMiddleMouseActive = false; 
                break; 
	    }
		mouseMove = false;
	}
	if (state == GLUT_DOWN)
	{
		oldMouseX = x;
		oldMouseY = y;

		switch (button)
		{
		case GLUT_LEFT_BUTTON:
            if ((modifiers & GLUT_ACTIVE_SHIFT) > 0)
    			isMiddleMouseActive = true;
            else {
			    isLeftMouseActive = true;
                trackball.StartDrag(x, y); 
            }
			break;
		case GLUT_RIGHT_BUTTON:
			isRightMouseActive = true; 
			break;
		case GLUT_MIDDLE_BUTTON:
			isMiddleMouseActive = true;
			break;
		}
	}		
}

void glut_mouseMotion(int x, int y)
{
	if (isLeftMouseActive) {
		mouseMove = true;
        trackball.Drag(x, y); 
		glutPostRedisplay(); 
	} 
	else if (isMiddleMouseActive) {
		mouseMove = true;
		transX += double(x - oldMouseX) * maxValue / 200.0; 
		transY -= double(y - oldMouseY) * maxValue  / 200.0; 
		glutPostRedisplay(); 
	}
	else if (isRightMouseActive) {
		mouseMove = true;
        scale += (y - oldMouseY) * scale/ 400.0;
		glutPostRedisplay(); 
	} 

	oldMouseX = x; oldMouseY = y; 
}

void glut_keyboard(unsigned char key, int x, int y)
{	
	switch (toupper(key))
	{
    case 'P':
        showPoints = !showPoints; 
        break; 
    case 'B':
        showBox = !showBox; 
        break; 
    case 'T':
        showTriangles = !showTriangles; 
        break; 
    case 'L':
        lightOn = !lightOn; 
        break; 
    case 'Q':
        trackball.Rotate(1.0, 0.0, 0.0, -3.141592654 / 100.0); 
        break; 
    case 'A':
        trackball.Rotate(1.0, 0.0, 0.0, 3.141592654 / 100.0); 
        break; 
    case 'W':
        trackball.Rotate(0.0, 1.0, 0.0, -3.141592654 / 100.0); 
        break; 
    case 'S':
        trackball.Rotate(0.0, 1.0, 0.0, 3.141592654 / 100.0); 
        break; 
    case 'E':
        trackball.Rotate(0.0, 0.0, 1.0, -3.141592654 / 100.0); 
        break; 
    case 'D':
        trackball.Rotate(0.0, 0.0, 1.0, 3.141592654 / 100.0); 
	case 'G':
		trackball.Reset();
		break;
	}
    glutPostRedisplay(); 
}

void setMaterial()
{
	glFrontFace(GL_CCW);
    //glPolygonMode(GL_FRONT, GL_FILL); 
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL); 
    glEnable(GL_LIGHTING); 
    glEnable(GL_LIGHT0); 
    glShadeModel(GL_SMOOTH); 
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(1.0, 1.0);

    glMatrixMode(GL_MODELVIEW); 
    glPushMatrix(); 
    glLoadIdentity(); 
    glTranslatef(transX, transY, 0.0);

    glTranslatef(0.5, 0.5, 0.5); 
    glScalef(scale, scale, scale);
    glTranslatef(-0.5, -0.5, -0.5); 
    // Skip the rotations

    GLfloat ambient[] = { .0f, .0f, .0f }; 
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient); 
    GLfloat difuse[] = { .9f, .9f, .9f }; 
    glLightfv(GL_LIGHT0, GL_DIFFUSE, difuse); 
    GLfloat position[] = { -1.5* maxValue , -1.5* maxValue , -1.5 * maxValue }; 
    glLightfv(GL_LIGHT0, GL_POSITION, position); 

    glPopMatrix(); 

    float mcolor[] = { .9f, .9f, .9f, .9f }; 
    float rcolor[] = { 1.0f, 0.0f, 0.0f, 1.0f }; 
    float bcolor[] = { 0.0f, 0.0f, 1.0f, 1.0f }; 
    float gcolor[] = { 0.01, 1.0f, 0.0f, 1.0f }; 

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, mcolor); 
}
void unsetMaterial()
{
    glDisable(GL_LIGHT0); 
    glDisable(GL_LIGHTING); 
    glDisable(GL_POLYGON_OFFSET_FILL);
    glPolygonMode(GL_FRONT, GL_FILL);
}
void drawPoints() 
{
	//draw the normal one
	glPointSize(1.0);
    glBegin(GL_POINTS); 
    glColor3d(1.0, 1.0, 0.0); 

	REAL vertex[3];
	gStar thisStar;
	for (int i = 0; i < ghull->GetVerticesNum() ; i++) {
		ghull->GetVertexAt(i, vertex);
		if(outputType == GHull::STAR)
		{
			ghull->GetStarAt(i, thisStar);
			if(thisStar.isDead)	//those dead vertices
			{
				glColor3d(0.8, 0.8, 0.8);
				glVertex3d(double(vertex[0]), double(vertex[1]), double(vertex[2])); 
				glColor3d(1.0, 1.0, 0.0); 
				continue;
			}
		}
		glVertex3d(double(vertex[0]), double(vertex[1]), double(vertex[2])); 
	}
    glEnd();
}
void drawBox() 
{
    glColor3d(0.5, 0.5, 0.5); 

    glBegin(GL_LINE_LOOP); 
        glVertex3d(0.0, 0.0, 0.0); glVertex3d(0.0, maxValue, 0.0); 
        glVertex3d(maxValue, maxValue, 0.0); glVertex3d(maxValue, 0.0, 0.0); 
    glEnd(); 
    glBegin(GL_LINE_LOOP); 
        glVertex3d(0.0, 0.0, maxValue); glVertex3d(0.0, maxValue, maxValue); 
        glVertex3d(maxValue, maxValue, maxValue); glVertex3d(maxValue, 0.0, maxValue); 
    glEnd(); 
    glBegin(GL_LINES); 
        glVertex3d(0.0, 0.0, 0.0); glVertex3d(0.0, 0.0, maxValue);
        glVertex3d(0.0, maxValue, 0.0); glVertex3d(0.0, maxValue, maxValue);
        glVertex3d(maxValue, maxValue, 0.0); glVertex3d(maxValue, maxValue, maxValue);
        glVertex3d(maxValue, 0.0, 0.0); glVertex3d(maxValue, 0.0, maxValue);
    glEnd(); 
}


void drawStars()
{  
	glColor3d(1.0, 0.3, 0.3); 
	//draw line
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); 
    glBegin(GL_LINES); 

	REAL vertex[3];	
	REAL neibor[3];
	gStar thisStar;
	int size = 0;
	for(int i = 0; i < ghull->GetStarsNum(); i++)
	{	
		ghull->GetVertexAt(i, vertex);
		ghull->GetStarAt(i, thisStar);
		if(thisStar.isDead) continue;
		
		int * thisNei = ghull->GetNeiIdsAroundStar(i, size);

		for(int j = 0 ; j < size; j ++)
		{
			int neiId = thisNei[j];
			if(i < neiId)
			{
				ghull->GetVertexAt(neiId, neibor);
				glVertex3d(vertex[0],vertex[1],vertex[2]);
				glVertex3d(neibor[0],neibor[1],neibor[2]);
			}
		}
	}
	glEnd();
	
	//draw triangles
    if (lightOn) {
		setMaterial();
		glBegin(GL_TRIANGLES); 

		REAL normal[3]; 
		REAL neibor1[3];
		REAL neibor2[3];
			
		for(int i = 0; i < ghull->GetStarsNum(); i++)
		{	
			ghull->GetVertexAt(i, vertex);
			ghull->GetStarAt(i, thisStar);
			if(thisStar.isDead) continue;
			if(thisStar.size<=0) continue;
			int * thisNei = ghull->GetNeiIdsAroundStar(i, size);

			for(int j = 0 ; j < size; j ++)
			{
				int id1 = thisNei[j];
				int id2 = thisNei[(j + 1) % size];
				if(i >id1 || i > id2) continue;
				ghull->GetVertexAt(id1, neibor1);
				ghull->GetVertexAt(id2, neibor2);
				
				normalVector(vertex, neibor1, neibor2, normal); 
				glNormal3d(normal[0], normal[1], normal[2]); 

				glVertex3d(vertex[0],vertex[1],vertex[2]);
				glVertex3d(neibor1[0],neibor1[1],neibor1[2]);
				glVertex3d(neibor2[0],neibor2[1],neibor2[2]);
			}
		}
        glEnd(); 
		unsetMaterial();
    }
}
void drawTriangles()
{
	glColor3d(1.0, 0.3, 0.3); 
	//draw line
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); 
    glBegin(GL_LINES);

	int triangle[3];
	REAL vertex[3];
	for(int i=0; i < ghull->GetTrianglesNum(); i++)
	{
		ghull->GetTriangleAt(i, triangle);
		if(triangle[0]<triangle[1])
		{
			ghull->GetVertexAt(triangle[0], vertex);
			glVertex3d(vertex[0],vertex[1],vertex[2]);
			ghull->GetVertexAt(triangle[1], vertex);
			glVertex3d(vertex[0],vertex[1],vertex[2]);
		}
		if(triangle[1]<triangle[2])
		{
			ghull->GetVertexAt(triangle[1], vertex);
			glVertex3d(vertex[0],vertex[1],vertex[2]);
			ghull->GetVertexAt(triangle[2], vertex);
			glVertex3d(vertex[0],vertex[1],vertex[2]);
		}
		if(triangle[2]<triangle[0])
		{
			ghull->GetVertexAt(triangle[2], vertex);
			glVertex3d(vertex[0],vertex[1],vertex[2]);
			ghull->GetVertexAt(triangle[0], vertex);
			glVertex3d(vertex[0],vertex[1],vertex[2]);
		}
	}
	glEnd();
	//draw triangles
    if (lightOn) {
		setMaterial();
		glBegin(GL_TRIANGLES); 
		
		REAL normal[3]; 
		int triangle[3];
		REAL vertex0[3];
		REAL vertex1[3];
		REAL vertex2[3];
		for(int i=0; i < ghull->GetTrianglesNum(); i++)
		{
			ghull->GetTriangleAt(i, triangle);
			ghull->GetVertexAt(triangle[0], vertex0);
			ghull->GetVertexAt(triangle[1], vertex1);
			ghull->GetVertexAt(triangle[2], vertex2);
			
			normalVector(vertex0, vertex1, vertex2, normal); 
			glNormal3d(normal[0], normal[1], normal[2]); 

			glVertex3d(vertex0[0],vertex0[1],vertex0[2]);
			glVertex3d(vertex1[0],vertex1[1],vertex1[2]);
			glVertex3d(vertex2[0],vertex2[1],vertex2[2]);			
		}

		glEnd();
		unsetMaterial();
	}

}
void glut_display()
{
	glViewport(0, 0, (GLsizei) winSize, (GLsizei) winSize); 
	glClearColor(0.0, 0.0, 0.0, 0.0); 
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); 
    
	// Setup projection matrix
	glMatrixMode(GL_PROJECTION); 
	glLoadIdentity(); 
    glOrtho(0.0-maxValue/5.0, maxValue+maxValue/5.0, 0.0-maxValue/5.0, 
		maxValue+maxValue/5.0, -maxValue*100, maxValue*100); 

	// Setup modelview matrix
	glMatrixMode(GL_MODELVIEW); 
	glLoadIdentity();

    glTranslatef(transX, transY, 0.0);
    glTranslatef(maxValue/2.0, maxValue/2.0, maxValue/2.0); 
    glScalef(scale, scale, scale);
    glMultMatrixd(trackball.GetRotationMatrix()); 
    glTranslatef(-maxValue/2.0, -maxValue/2.0, -maxValue/2.0); 

	// Setting up lights
	glDisable(GL_LIGHTING); 
	glEnable(GL_DEPTH_TEST); 

	glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(1.0, 1.0);

    // Draw the bounding box
	if(showBox)
		drawBox(); 

    // Draw triangles
	if(showTriangles)
	{
		if(outputType == GHull::STAR)
			drawStars(); 
		if(outputType == GHull::TRIANGLE)
			drawTriangles(); 
	}

	// Draw input points
	if(showPoints)
		drawPoints(); 

	glutSwapBuffers();    
}
void printTest(int device, int seedNum, int outputType, int fboSize, int projectionSize, 
			   int screenSize, int maxValue, float ballfactor, float thickness, int distribution)
{
	string disstr;
	switch(distribution){
		case 0: disstr="Cube";break;
		case 1: disstr="Ball";break;
		case 2: disstr="Thin Sphere";break;
		case 3: disstr="Thin Cube";break;
		case 4: disstr="Sphere";break;
		case 5: disstr="Customized";break;	
		default: disstr="Unknown";break;
	}
	string typestr="";
	switch(outputType){
		case GHull::STAR: typestr="Star";break;
		case GHull::TRIANGLE: typestr="Triangle";break;			
	}
	printf("----------------------running parameters----------------------\n");
	printf("Point Set:\n");
	printf("***Seed Number:   %d\n",seedNum);
	printf("***Point Domain:  (0.0 - %d.0)\n",maxValue);
	printf("***Distribution:  %s\n",disstr.c_str());
	printf("***Ball Factor:   %f\n", ballfactor);
	printf("***Thickness:     %f\n", thickness);
	printf("GHull Computation:\n");
	printf("***Device ID:     %d\n",device);
	printf("***Output Type:   %s\n",typestr.c_str());
	printf("***Texture Size:  %d\n",fboSize);
	printf("***Project Size:  %d\n",projectionSize);
	printf("***Screen Size:   %d\n",screenSize);
	printf("--------------------------------------------------------------\n");
}

void printShortTest(int seedNum, int outputType, int fboSize, int projectionSize, 
			   int screenSize, int maxValue, float ballfactor, float thickness, int distribution)
{
	string disstr;
	switch(distribution){
		case 0: disstr="Cube";break;
		case 1: disstr="Ball";break;
		case 2: disstr="Thin Sphere";break;
		case 3: disstr="Thin Cube";break;
		case 4: disstr="Sphere";break;
		case 5: disstr="Customized";break;	
		default: disstr="Unknown";break;
	}
	string typestr="";
	switch(outputType){
		case GHull::STAR: typestr="Star";break;
		case GHull::TRIANGLE: typestr="Triangle";break;			
	}
	printf("*** Points Config: ");
	printf("%i ",seedNum);
	printf("%i.0 ",maxValue);
	printf("%s ",disstr.c_str());
	printf("%f ", ballfactor);
	printf("%f ", thickness);
	printf("\n");
	printf("*** Compute Config: ");
	printf("%s ",typestr.c_str());
	printf("%d ",fboSize);
	printf("%d ",projectionSize);
	printf("%d ",screenSize);
	printf("\n");
	printf("\n");
}